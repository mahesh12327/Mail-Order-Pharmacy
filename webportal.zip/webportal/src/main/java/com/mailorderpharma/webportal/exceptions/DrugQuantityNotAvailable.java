package com.mailorderpharma.webportal.exceptions;

public class DrugQuantityNotAvailable extends Exception {
	
	public  DrugQuantityNotAvailable(String message) {
		super(message);
	}
			
}
