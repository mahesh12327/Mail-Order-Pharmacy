package com.mailorderpharma.webportal.exceptions;

public class InvalidTokenException extends Exception {

	public InvalidTokenException(String message){
		super(message);
	}
}
