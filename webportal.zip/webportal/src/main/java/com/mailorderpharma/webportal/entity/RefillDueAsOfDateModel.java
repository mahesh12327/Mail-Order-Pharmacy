package com.mailorderpharma.webportal.entity;

public class RefillDueAsOfDateModel {

	String memberId;
	int date;
}
