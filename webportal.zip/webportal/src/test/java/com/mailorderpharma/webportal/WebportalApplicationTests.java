package com.mailorderpharma.webportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
