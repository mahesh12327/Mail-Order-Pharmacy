//package com.mailorderpharma.refill;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest(classes=RefillMicroserviceApplicationTests.class)
//class RefillMicroserviceApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
