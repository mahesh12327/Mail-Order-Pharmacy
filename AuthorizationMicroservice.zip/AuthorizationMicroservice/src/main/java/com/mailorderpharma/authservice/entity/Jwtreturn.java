package com.mailorderpharma.authservice.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Jwtreturn {
	
	private final String jwt;

}
