insert into user (userid,upassword,uname) values ('admin','admin','admin');
insert into user (userid,upassword,uname) values ('admin1','admin1','admin1');
insert into user (userid,upassword,uname) values ('admin2','admin2','admin2');
insert into user (userid,upassword,uname) values ('admin3','admin3','admin3');